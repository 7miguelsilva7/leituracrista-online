<?php $__env->startSection('title','Create'); ?>
<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Create indice
    </h1>
    <form method = 'get' action = '<?php echo url("indice"); ?>'>
        <button class = 'btn btn-danger'>indice Index</button>
    </form>
    <br>
    <form method = 'POST' action = '<?php echo url("indice"); ?>'>
        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
        <div class="form-group">
            <label for="pergunta">pergunta</label>
            <input id="pergunta" name = "pergunta" type="text" class="form-control">
        </div>
        <div class="form-group">
            <label for="link">link</label>
            <input id="link" name = "link" type="text" class="form-control">
        </div>
        <div class="form-group">
            <label for="tags">tags</label>
            <input id="tags" name = "tags" type="text" class="form-control">
        </div>
        <button class = 'btn btn-primary' type ='submit'>Create</button>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('scaffold-interface.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
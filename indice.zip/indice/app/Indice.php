<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Indice.
 *
 * @author  The scaffold-interface created at 2017-07-15 11:42:26pm
 * @link  https://github.com/amranidev/scaffold-interface
 */
class Indice extends Model
{
	
	
    protected $table = 'indices';

	
}

<?php $__env->startSection('content'); ?>
<div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Permissões:</div>

    <div class="panel-body">
			<h3>Permissões</h3>
		<div class="box-body">
			<a href="<?php echo e(url('permission/create')); ?>" class = "btn btn-success"><i class="fa fa-plus fa-md" aria-hidden="true"></i> Add</a>
			<table class="table table-striped">
				<head>
					<th>Permission</th>
					<th>Actions</th>
				</head>
				<tbody>
					<?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($permission->name); ?></td>
						<td>
							<a  class = 'viewEdit btn btn-primary btn-xs' href = "<?php echo e(url('/permission/edit')); ?>/<?php echo e($permission->id); ?>"><i class = 'material-icons'> edit</i></a>
							<a  class = 'delete btn btn-danger btn-xs' href="<?php echo e(url('/permission/delete')); ?>/<?php echo e($permission->id); ?>" ><i class = 'material-icons'> delete</i></a>

						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title','Show'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Assembleia </div>

    <div class="panel-body"> 
    <br>
    <a href='<?php echo url("assembleia"); ?>' class = 'btn btn-primary'><i class="fa fa-home"></i> <b> Voltar</b></a>
    <br>
    <table class = 'table table-bordered'>
        <thead>
            <th>#</th>
            <th></th>
        </thead>
        <tbody>
            <tr>
                <td> <b>Endereço de Reuniao</b> </td>
                <td><?php echo $assembleia->endereco_reuniao; ?></td>
            </tr>
            <!-- <tr>
                <td>
                    <b><i>codigo : </i></b>
                </td>
                <td><?php echo $assembleia->municipio->codigo; ?></td>
            </tr> -->
            <tr>
                <td>
                    <b><i>Cidade : </i></b>
                </td>
                <td><?php echo $assembleia->municipio->nome; ?></td>
            </tr>
            <tr>
                <td>
                    <b><i>Estado : </i></b>
                </td>
                <td><?php echo $assembleia->municipio->uf; ?></td>
            </tr>
             <tr>
                <td>
                    <b><i>Cep : </i></b>
                </td>
                <td><?php echo $assembleia->cep; ?></td>
            </tr>
          <!--  <tr>
                <td>
                    <b><i>updated_at : </i></b>
                </td>
                <td><?php echo $assembleia->municipio->updated_at; ?></td>
            </tr> -->
        </tbody>
    </table>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
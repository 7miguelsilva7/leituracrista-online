</div>
<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    <button type="button" class="destroy btn btn-primary" data-link = "<?php echo e($link); ?>"><?php echo e($action); ?></button>
</div></div></div>

<div class="container">
	<h2 class="thin">Whoops!!</h2>
	<h5 class = "thin">Seems like you want to delete <strong><i><?php echo e($table); ?></i> MVC files</strong></h5>
	<h5 class="thin">Please rollback <strong><i><?php echo e($table); ?></i></strong> schema and try again!!</h5>
</div>

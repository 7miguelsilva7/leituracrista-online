use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class <?php echo e(ucfirst($first)); ?><?php echo e(ucfirst($second)); ?> extends Migration
{
    /**
     * Run the migrations.
     *
     * @return  void
     */
    public function up()
    {
        Schema::create('<?php echo e(str_singular($first)); ?>_<?php echo e(str_singular($second)); ?>',function (Blueprint $table){
			$table->increments('id')->unique()->index()->unsigned();
			$table->integer('<?php echo e(str_singular($first)); ?>_id')->unsigned()->index();
			$table->foreign('<?php echo e(str_singular($first)); ?>_id')->references('id')->on('<?php echo e($first); ?>')->onDelete('cascade');
			$table->integer('<?php echo e(str_singular($second)); ?>_id')->unsigned()->index();
			$table->foreign('<?php echo e(str_singular($second)); ?>_id')->references('id')->on('<?php echo e($second); ?>')->onDelete('cascade');
			/**
			 * Type your addition here
			 *
			 */
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return  void
     */
    public function down()
    {
        Schema::drop('<?php echo e(str_singular($first)); ?>_<?php echo e(str_singular($second)); ?>');
    }
}

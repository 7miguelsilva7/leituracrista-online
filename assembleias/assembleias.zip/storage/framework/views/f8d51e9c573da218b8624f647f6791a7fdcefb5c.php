<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Editar Regras:</div>

    <div class="panel-body">
			<h3>Editar Regras</h3>
		<div class="box-body">
			<form action="<?php echo e(url('role/update')); ?>" method = "post">
				<?php echo csrf_field(); ?>

				<input type="hidden" name = "role_id" value = "<?php echo e($role->id); ?>">
				<div class="form-group">
				<label for="">Role</label>
					<input type="text" name = "name" class = "form-control" placeholder = "Name" value = "<?php echo e($role->name); ?>">
				</div>
				<div class="box-footer">
					<button class = 'btn btn-primary' type = "submit">Update</button>
				</div>
			</form>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
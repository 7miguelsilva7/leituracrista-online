<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Regras:</div>

    <div class="panel-body">
    
    <div class="form-group">
			<a href="<?php echo e(url('role/create')); ?>" class = "btn btn-success"><i class="fa fa-plus fa-md" aria-hidden="true"></i> Add</a>
			<table class="table table-striped">
				<head>
					<th>Regras</th>
					<th>Ações</th>
				</head>
				<tbody>
					<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($role->name); ?></td>
						<td>
							<a  class = 'viewEdit btn btn-primary btn-xs' href = "<?php echo e(url('/role/edit')); ?>/<?php echo e($role->id); ?>"><i class = 'material-icons'> edit</i></a>
							<a  class = 'delete btn btn-danger btn-xs' href="<?php echo e(url('/role/delete')); ?>/<?php echo e($role->id); ?>" ><i class = 'material-icons'> delete</i></a>
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
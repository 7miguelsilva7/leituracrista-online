<?php $__env->startSection('title','Create'); ?>
<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Adicionar Assembleia </div>

    <div class="panel-body">    
    <a href="<?php echo url('assembleia'); ?>" class = 'btn btn-danger'><i class="fa fa-home"></i> <b> Cancelar</b></a>
    <br>
    <form method = 'POST' action = '<?php echo url("assembleia"); ?>'>
        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
        <div class="form-group">
            <label for="endereco_reuniao">Endereço de Reunião</label>
            <input id="endereco_reuniao" name = "endereco_reuniao" type="text" class="form-control" required>
        </div>
        <div class="form-group">
        <label>Cidade</label>
            <select name = 'municipio_id' class = "form-control js-example-basic-single" required>
                <option value="">Selecione uma Cidade</option>
                <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <option value="<?php echo $municipio->id; ?>"><?php echo $municipio->uf; ?> - <?php echo $municipio->nome; ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </select> <p></p>        
        </div>
        <div class="form-group">
            <label for="cep">Cep</label>
            <input id="cep" name = "cep" type="text" class="form-control" required>
        </div>
        
        <button class = 'btn btn-success' type ='submit'> <i class="fa fa-floppy-o"></i> Savar</button>
    </form>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
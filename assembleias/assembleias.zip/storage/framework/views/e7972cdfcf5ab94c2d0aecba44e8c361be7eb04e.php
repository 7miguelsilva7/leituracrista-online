@extends('scaffold-interface.layouts.app')
@section('title','Create')
@section('content')
<section class="content">
    <h1>Create <?php echo e($parser->singular()); ?></h1>
        <a href="{!!url('<?php echo e($parser->singular()); ?>')!!}" class = 'btn btn-danger'><i class="fa fa-home"></i> <?php echo e($parser->upperCaseFirst()); ?> Index</a>
    <br>
    <form method = 'POST' action = '{!!url("<?php echo e($parser->singular()); ?>")!!}'>
        <input type = 'hidden' name = '_token' value = '{{Session::token()}}'>
        <?php $__currentLoopData = $dataSystem->dataScaffold('v'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group">
            <label for="<?php echo e($value); ?>"><?php echo e($value); ?></label>
            <input id="<?php echo e($value); ?>" name = "<?php echo e($value); ?>" type="text" class="form-control">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $dataSystem->getForeignKeys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group">
            <label><?php echo e($key); ?> Select</label>
            <select name = '<?php echo e(lcfirst(str_singular($key))); ?>_id' class = 'form-control'>
                @foreach($<?php echo e(str_plural($key)); ?> as $key => $value)
                <option value="{{$key}}">{{$value}}</option>
                @endforeach
            </select>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button class = 'btn btn-success' type ='submit'> <i class="fa fa-floppy-o"></i> Save</button>
    </form>
</section>
@endsection

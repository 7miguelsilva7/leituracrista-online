namespace <?php echo e(config('amranidev.config.controllerNameSpace')); ?>;

use Illuminate\Support\Facades\App;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use <?php echo e(config('amranidev.config.modelNameSpace')); ?>\<?php echo e(ucfirst($parser->singular())); ?>;
use Amranidev\Ajaxis\Ajaxis;
use URL;
<?php $__currentLoopData = $dataSystem->getForeignKeys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

use <?php echo e(config('amranidev.config.modelNameSpace')); ?>\<?php echo e(ucfirst(str_singular($key))); ?>;

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

/**
 * Class <?php echo e(ucfirst($parser->singular())); ?>Controller.
 *
 * @author  The scaffold-interface created at <?php echo e(date("Y-m-d h:i:sa")); ?>

 * @link  https://github.com/amranidev/scaffold-interface
 */
class <?php echo e(ucfirst($parser->singular())); ?>Controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return  \Illuminate\Http\Response
     */
    public function index()
    {
        $title = 'Index - <?php echo e($parser->singular()); ?>';
        $<?php echo e($parser->plural()); ?> = <?php echo e(ucfirst($parser->singular())); ?>::paginate(6);
        return view('<?php if(config('amranidev.config.loadViews')): ?><?php echo e(config('amranidev.config.loadViews')); ?>::<?php endif; ?><?php echo e($parser->singular()); ?>.index',compact('<?php echo e($parser->plural()); ?>','title'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return  \Illuminate\Http\Response
     */
    public function create()
    {
        $title = 'Create - <?php echo e($parser->singular()); ?>';
        <?php $__currentLoopData = $dataSystem->getForeignKeys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        $<?php echo e(str_plural($value)); ?> = <?php echo e(ucfirst(str_singular($value))); ?>::all()->pluck('<?php echo e($dataSystem->getOnData()[$key]); ?>','id');
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        return view('<?php if(config('amranidev.config.loadViews')): ?><?php echo e(config('amranidev.config.loadViews')); ?>::<?php endif; ?><?php echo e($parser->singular()); ?>.create'<?php if($dataSystem->getForeignKeys() != null): ?>,compact('title',<?php $__currentLoopData = $dataSystem->getForeignKeys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>'<?php echo e(str_plural($value)); ?>' <?php if($value != last($dataSystem->getForeignKeys())): ?>,<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>)<?php endif; ?>);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param    \Illuminate\Http\Request  $request
     * @return  \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $<?php echo e($parser->singular()); ?> = new <?php echo e(ucfirst($parser->singular())); ?>();

        <?php $__currentLoopData = $dataSystem->dataScaffold('v'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        $<?php echo e($parser->singular()); ?>-><?php echo e($value); ?> = $request-><?php echo e($value); ?>;

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $dataSystem->getForeignKeys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        $<?php echo e($parser->singular()); ?>-><?php echo e(lcfirst(str_singular($key))); ?>_id = $request-><?php echo e(lcfirst(str_singular($key))); ?>_id;

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        $<?php echo e($parser->singular()); ?>->save();

        $pusher = App::make('pusher');

        //default pusher notification.
        //by default channel=test-channel,event=test-event
        //Here is a pusher notification example when you create a new resource in storage.
        //you can modify anything you want or use it wherever.
        $pusher->trigger('test-channel',
                         'test-event',
                        ['message' => 'A new <?php echo e($parser->singular()); ?> has been created !!']);

        return redirect('<?php echo e($parser->singular()); ?>');
    }

    /**
     * Display the specified resource.
     *
     * @param    \Illuminate\Http\Request  $request
     * @param    int  $id
     * @return  \Illuminate\Http\Response
     */
    public function show($id,Request $request)
    {
        $title = 'Show - <?php echo e($parser->singular()); ?>';

        if($request->ajax())
        {
            return URL::to('<?php echo e($parser->singular()); ?>/'.$id);
        }

        $<?php echo e($parser->singular()); ?> = <?php echo e(ucfirst($parser->singular())); ?>::findOrfail($id);
        return view('<?php if(config('amranidev.config.loadViews')): ?><?php echo e(config('amranidev.config.loadViews')); ?>::<?php endif; ?><?php echo e($parser->singular()); ?>.show',compact('title','<?php echo e($parser->singular()); ?>'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param    \Illuminate\Http\Request  $request
     * @param    int  $id
     * @return  \Illuminate\Http\Response
     */
    public function edit($id,Request $request)
    {
        $title = 'Edit - <?php echo e($parser->singular()); ?>';
        if($request->ajax())
        {
            return URL::to('<?php echo e($parser->singular()); ?>/'. $id . '/edit');
        }

        <?php $__currentLoopData = $dataSystem->getForeignKeys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        $<?php echo e(str_plural($value)); ?> = <?php echo e(ucfirst(str_singular($value))); ?>::all()->pluck('<?php echo e($dataSystem->getOnData()[$key]); ?>','id');

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        $<?php echo e($parser->singular()); ?> = <?php echo e(ucfirst($parser->singular())); ?>::findOrfail($id);
        return view('<?php if(config('amranidev.config.loadViews')): ?><?php echo e(config('amranidev.config.loadViews')); ?>::<?php endif; ?><?php echo e($parser->singular()); ?>.edit',compact('title','<?php echo e($parser->singular()); ?>' <?php if($dataSystem->getForeignKeys() != null): ?>,<?php $__currentLoopData = $dataSystem->getForeignKeys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>'<?php echo e(str_plural($value)); ?>'<?php if($value != last($dataSystem->getForeignKeys())): ?>,<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>) <?php else: ?> )<?php endif; ?>);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param    \Illuminate\Http\Request  $request
     * @param    int  $id
     * @return  \Illuminate\Http\Response
     */
    public function update($id,Request $request)
    {
        $<?php echo e($parser->singular()); ?> = <?php echo e(ucfirst($parser->singular())); ?>::findOrfail($id);
    	<?php $__currentLoopData = $dataSystem->dataScaffold('v'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        $<?php echo e($parser->singular()); ?>-><?php echo e($value); ?> = $request-><?php echo e($value); ?>;
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php $__currentLoopData = $dataSystem->getForeignKeys(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        $<?php echo e($parser->singular()); ?>-><?php echo e(lcfirst(str_singular($key))); ?>_id = $request-><?php echo e(lcfirst(str_singular($key))); ?>_id;

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        $<?php echo e($parser->singular()); ?>->save();

        return redirect('<?php echo e($parser->singular()); ?>');
    }

    /**
     * Delete confirmation message by Ajaxis.
     *
     * @link      https://github.com/amranidev/ajaxis
     * @param    \Illuminate\Http\Request  $request
     * @return  String
     */
    public function DeleteMsg($id,Request $request)
    {
        $msg = Ajaxis::<?php echo e($parser->getParse()); ?>Deleting('Warning!!','Would you like to remove This?','/<?php echo e($parser->singular()); ?>/'. $id . '/delete');

        if($request->ajax())
        {
            return $msg;
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param    int $id
     * @return  \Illuminate\Http\Response
     */
    public function destroy($id)
    {
     	$<?php echo e($parser->singular()); ?> = <?php echo e(ucfirst($parser->singular())); ?>::findOrfail($id);
     	$<?php echo e($parser->singular()); ?>->delete();
        return URL::to('<?php echo e($parser->singular()); ?>');
    }
}

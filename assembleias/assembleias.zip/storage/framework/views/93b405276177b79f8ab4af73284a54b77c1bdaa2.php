</div>
<div class="modal-footer">
<a  href = "#" class=" modal-action waves-effect waves-green btn-flat closeModal">close</a>
<button class="waves-effect waves-green btn-flat" type = "submit"><?php echo e($action); ?></a>
</div>
</form>

<?php $__env->startSection('title','Index'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Assembleias</div>

    <div class="panel-body">
    
    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
    <a href='<?php echo url("assembleia"); ?>/create' class = 'btn btn-success'><i class="fa fa-plus"></i> <b> NOVO</b></a>
    <br>
    <div class="dropdown">
        <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"> Associar <span class="caret"></span> </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
            <li><a href="http://127.0.0.1:8000/municipio">Cidade</a></li>
        </ul>
    </div>
    <?php endif; ?>

    <br>
                        <div class="navbar-form navbar-right">
                            <form action='<?php echo url("assembleia"); ?>' method="get">
                                <!-- <?php echo e(csrf_field()); ?> -->
                                <label class="control-label">Pesquisar</label>

                                <input type="search" class="form-control input-sm" name="search" value="<?php echo e($search); ?>">

                                <button type="submit" class="btn btn-primary btn-xs" title="Pesquisar">
                                    <span ><i class="material-icons">
search
</i></span>
                                </button>
                            </form>
                        </div>


    <table class = "table table-striped table-bordered table-hover" style = 'background:#fff'>
        <thead>
            <th>Endereço de Reuniões</th>
            <th>Cidade</th>
            <th>Estado</th>
            <th>Ações</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $assembleias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assembleia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <td><?php echo $assembleia->endereco_reuniao; ?></td>
                <td><?php echo $assembleia->municipio->nome; ?></td>
                <td><?php echo $assembleia->municipio->uf; ?></td>
                <td>
                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                    <a data-toggle="modal" data-target="#myModal" class = 'delete btn btn-danger btn-xs' data-link = "/assembleia/<?php echo $assembleia->id; ?>/deleteMsg" ><i class = 'material-icons'> delete</i></a>
                    <a href = '#' class = 'viewEdit btn btn-primary btn-xs' data-link = '/assembleia/<?php echo $assembleia->id; ?>/edit'><i class = 'material-icons'> edit</i></a>
                <?php endif; ?>
                    <a href = '#' class = 'viewShow btn btn-warning btn-xs' data-link = '/assembleia/<?php echo $assembleia->id; ?>'><i class = 'material-icons'> info</i></a>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </tbody>
    </table>
    <!-- <?php echo $assembleias->render(); ?> -->
    <?php echo e($assembleias->appends(['search' => $search])->links()); ?>



</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
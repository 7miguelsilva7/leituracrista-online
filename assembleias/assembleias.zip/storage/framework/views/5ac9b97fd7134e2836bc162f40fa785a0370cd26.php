<?php $__env->startSection('title','Edit'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Editar Assembleia </div>

    <div class="panel-body"> 
    <a href="<?php echo url('assembleia'); ?>" class = 'btn btn-primary'><i class="fa fa-home"></i> <b> Voltar</b></a>
    <br>
    <form method = 'POST' action = '<?php echo url("assembleia"); ?>/<?php echo $assembleia->
        id; ?>/update'> 
        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
        <div class="form-group">
            <label for="endereco_reuniao">Endereço de Reuniao</label>
            <input id="endereco_reuniao" name = "endereco_reuniao" type="text" class="form-control" value="<?php echo $assembleia->
            endereco_reuniao; ?>"> 
        </div>
        <div class="form-group">
            <label>Cidade</label>
            <select name = 'municipio_id' class = "form-control js-example-basic-single" required>
                <option value="<?php echo $assembleia->municipio->id; ?>"><?php echo $assembleia->municipio->nome; ?></option>
                <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </select>
        </div>
        <div class="form-group">
            <label for="cep">Cep</label>
            <input id="cep" name = "cep" type="text" class="form-control" value="<?php echo $assembleia->
            cep; ?>">
        </div>

        <button class = 'btn btn-success' type ='submit'><i class="fa fa-floppy-o"></i> Atualizar</button>
    </form>
</section>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<form class="col s12"  method = "post" enctype="multipart/form-data" action = "<?php echo e(url('/')); ?><?php echo e($link); ?>">
    <input type = "hidden" name = "_token" value = "<?php echo e(csrf_token()); ?>">
    <div class="modal-content"><h4> <?php echo e($title); ?> </h4>

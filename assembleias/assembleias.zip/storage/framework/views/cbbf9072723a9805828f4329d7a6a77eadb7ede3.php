<?php $__env->startSection('title','Index'); ?>
<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Usuários</div>

    <div class="panel-body">
		<a href="<?php echo e(url('/user/create')); ?>" class = "btn btn-success"><i class="fa fa-plus fa-md" aria-hidden="true"></i> NOVO</a>
		<table class = "table table-hover">
		<thead>
			<th>Name</th>
			<th>Email</th>
			<th>Roles</th>
			<th>Permissions</th>
			<th>Actions</th>
		</thead>
		<tbody>
			<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($user->name); ?></td>
				<td><?php echo e($user->email); ?></td>
				<td>
				<?php if(!empty($user->roles)): ?>
					<?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<small class = 'label bg-blue'><?php echo e($role->name); ?></small>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<small class = 'label bg-red'>No Roles</small>
				<?php endif; ?>
				</td>
				<td>
				<?php if(!empty($user->permissions)): ?>
					<?php $__currentLoopData = $user->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<small class = 'label bg-orange'><?php echo e($permission->name); ?></small>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<small class = 'label bg-red'>No Permissions</small>
				<?php endif; ?>
				</td>
				<td>
					<!-- <a href="<?php echo e(url('/scaffold-users/edit')); ?>/<?php echo e($user->id); ?>" class = 'viewEdit btn btn-primary btn-xs'><i class="material-icons" aria-hidden="true"></i></a>
					<a href="<?php echo e(url('scaffold-users/delete')); ?>/<?php echo e($user->id); ?>" class = "delete btn btn-danger btn-xs"><i class="material-icons" aria-hidden="true"></i></a> -->

					<a  class = 'delete btn btn-danger btn-xs' href="/user/<?php echo $user->id; ?>/delete" ><i class = 'material-icons'> delete</i></a>
                    <a  class = 'viewEdit btn btn-primary btn-xs' href = "/user/<?php echo $user->id; ?>/edit"><i class = 'material-icons'> edit</i></a>

				
				</td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</div>
</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
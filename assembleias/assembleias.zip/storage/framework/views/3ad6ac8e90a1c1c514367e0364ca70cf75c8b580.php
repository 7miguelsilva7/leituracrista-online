    /**
     * <?php echo e(str_singular($model)); ?>.
     *
     * @return  \Illuminate\Support\Collection;
     */
    public function <?php echo e(str_plural($model)); ?>()
    {
        return $this->belongsToMany('<?php echo e(config('amranidev.config.modelNameSpace')); ?>\<?php echo e(ucfirst(str_singular($model))); ?>');
    }

    /**
     * Assign a <?php echo e(str_singular($model)); ?>.
     *
     * @param  $<?php echo e(str_singular($model)); ?>

     * @return  mixed
     */
    public function assign<?php echo e(ucfirst(str_singular($model))); ?>($<?php echo e(str_singular($model)); ?>)
    {
        return $this-><?php echo e(str_plural($model)); ?>()->attach($<?php echo e(str_singular($model)); ?>);
    }
    /**
     * Remove a <?php echo e(str_singular($model)); ?>.
     *
     * @param  $<?php echo e(str_singular($model)); ?>

     * @return  mixed
     */
    public function remove<?php echo e(ucfirst(str_singular($model))); ?>($<?php echo e(str_singular($model)); ?>)
    {
        return $this-><?php echo e(str_plural($model)); ?>()->detach($<?php echo e(str_singular($model)); ?>);
    }

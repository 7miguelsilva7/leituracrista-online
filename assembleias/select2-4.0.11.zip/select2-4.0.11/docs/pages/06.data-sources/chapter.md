---
title: Data sources
taxonomy:
    category: docs
---

# Data sources

In addition to handling `<option>` elements that explicitly appear in your markup, Select2 can also retrieve the results from other data sources such as a remote JSON API or a local Javascript array.
